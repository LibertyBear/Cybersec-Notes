#CIFRADO MAYUSCULAS
def cifradoCesarAlfabetoInglesMAY(cadena):
    """Devuelve un cifrado Cesar tradicional (+3)"""
    # Definir la nueva cadena resultado
    resultado = ''
    # Realizar el "cifrado", sabiendo que A = 65, Z = 90, a = 97, z = 122
    i = 0
    while i < len(cadena):
        # Recoge el caracter a cifrar
        ordenClaro = ord(cadena[i])
        ordenCifrado = 0
        # Cambia el caracter a cifrar
        if (ordenClaro >= 65 and ordenClaro <= 90):
            ordenCifrado = (((ordenClaro - 65) + 3) % 26) + 65
        # Añade el caracter cifrado al resultado
        resultado = resultado + chr(ordenCifrado)
        i = i + 1
    # devuelve el resultado
    return resultado

palabra = 'VENI VIDI VINCI AURIA'
print(palabra)
cifrado = cifradoCesarAlfabetoInglesMAY(palabra) 
print(cifrado)

#DESCIFRADO MAYUSCULAS
def descifradoMAY(cadenaCifrada):
    
    cadenaDescifrada = ""
    
    i = 0
    while i < len(cadenaCifrada):
        
        ordenCifrado = ord(cadenaCifrada[i])
        ordenClaro = 0
        
        if(ordenCifrado >= 65 and ordenCifrado <= 90):
            ordenClaro = (((ordenCifrado-65) -3) % 26) + 65
        
        cadenaDescifrada = cadenaDescifrada + chr(ordenClaro)
        
        i = i + 1
    
    return cadenaDescifrada

print("Probamos el descifrado:")
descifrado = descifradoMAY(cifrado) 
print(descifrado)







#CIFRADO MAYUSCULAS y MINUSCULAS
def cifradoCesarAlfabetoInglesMAYMIN(cadena):
    """Devuelve un cifrado Cesar tradicional (+3)"""
    # Definir la nueva cadena resultado
    resultado = ''
    # Realizar el "cifrado", sabiendo que A = 65, Z = 90, a = 97, z = 122
    i = 0
    while i < len(cadena):
        # Recoge el caracter a cifrar
        ordenClaro = ord(cadena[i])
        ordenCifrado = 0
        # Cambia el caracter a cifrar
        if (ordenClaro >= 65 and ordenClaro <= 90):
            ordenCifrado = (((ordenClaro - 65) + 3) % 26) + 65
        
        if(ordenClaro >= 97 and ordenClaro <= 122):
            ordenCifrado = (((ordenClaro - 97) +3) % 26) + 97
        # Añade el caracter cifrado al resultado
        resultado = resultado + chr(ordenCifrado)
        i = i + 1
    # devuelve el resultado
    return resultado

print("AHORA CON MAYUSCULAS Y MINUSCULAS")
palabra = 'Bauti Es'
print(palabra)
cifrado = cifradoCesarAlfabetoInglesMAY(palabra) 
print(cifrado)

 
#DESCIFRADO MAYUSCULAS y MINUSCULAS
def descifradoMAYMIN(cadenaCifrada):
    
    cadenaDescifrada = ""
    
    i = 0
    while i < len(cadenaCifrada):
        
        ordenCifrado = ord(cadenaCifrada[i])
        ordenClaro = 0
        
        if(ordenCifrado >= 65 and ordenCifrado <= 90):
            ordenClaro = (((ordenCifrado-65) -3) % 26) + 65
        
        if(ordenCifrado >= 97 and ordenCifrado <= 122):
            ordenClaro = (((ordenCifrado - 97) -3) % 26) + 97
            
        cadenaDescifrada = cadenaDescifrada + chr(ordenClaro)
        
        i = i + 1
    
    return cadenaDescifrada

descifrado = descifradoMAY(cifrado) 
print(descifrado)







#CIFRADO SECRETO
def cifradoSecreto(cadena, secreto):
    resultado = ''

    i = 0
    while i < len(cadena):
        
        ordenClaro = ord(cadena[i])
        ordenCifrado = 0
        
        ordenSecreto = ord(secreto[i%len(secreto)])
        
        if(cadena[i] == " "):
            ordenCifrado = ord(" ")
            
        if (ordenClaro >= 65 and ordenClaro <= 90):
            ordenCifrado = (((ordenClaro - 65) + (ordenSecreto - 65 + 1)) % 26) + 65
        
        if(ordenClaro >= 97 and ordenClaro <= 122):
            ordenCifrado = (((ordenClaro - 97) + (ordenSecreto - 97 + 1)) % 26) + 97
        
        resultado = resultado + chr(ordenCifrado)
        i = i + 1

    # devuelve el resultado
    return resultado

print("AHORA CON SECRETO")
palabra = 'Mesa y Silla'
secreto = 'hELaDo'
print(palabra)
cifrado = cifradoSecreto(palabra, secreto) 
print(cifrado)

 
#DESCIFRADO SECRETO
def descifradoSecreto(cadenaCifrada, secreto):
    
    cadenaDescifrada = ""
    
    i = 0
    while i < len(cadenaCifrada):
        
        ordenCifrado = ord(cadenaCifrada[i])
        ordenClaro = 0
        
        ordenSecreto = ord(secreto[i%len(secreto)])
        
        if(cadenaCifrada[i] == " "):
            ordenClaro = ord(" ")

        if(ordenCifrado >= 65 and ordenCifrado <= 90):
            ordenClaro = (((ordenCifrado-65) - (ordenSecreto - 65 + 1)) % 26) + 65
        
        if(ordenCifrado >= 97 and ordenCifrado <= 122):
            ordenClaro = (((ordenCifrado - 97) - (ordenSecreto - 97 + 1)) % 26) + 97
            
        cadenaDescifrada = cadenaDescifrada + chr(ordenClaro)
        
        i = i + 1
    
    return cadenaDescifrada

descifrado = descifradoSecreto(cifrado, secreto) 
print(descifrado)






