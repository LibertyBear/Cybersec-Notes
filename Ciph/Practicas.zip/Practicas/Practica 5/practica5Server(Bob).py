from hashlib import sha256
from hmac import HMAC
import json
from socket_class import SOCKET_SIMPLE_TCP
import funciones_aes
import funciones_rsa
from Crypto.Hash import HMAC, SHA256

# Cargo la clave pública de Alice y la clave privada de Bob
pubAlice = funciones_rsa.cargar_RSAKey_Publica("rsa_alice.pub")
privBob = funciones_rsa.cargar_RSAKey_Privada("rsa_bob.pem", "bob")


#Inicializar Server y esperar Cliente:
socketserver = SOCKET_SIMPLE_TCP('127.0.0.1', 5551)
socketserver.escuchar()

#Recibir Claves from Alice y la firma
k1Cifrada = socketserver.recibir()
k2Cifrada = socketserver.recibir()
K1K2_fir = socketserver.recibir()

# Descifro las claves K1 y K2 con privBob
k1 = funciones_rsa.descifrarRSA_OAEP_BIN(k1Cifrada, privBob)
k2 = funciones_rsa.descifrarRSA_OAEP_BIN(k2Cifrada, privBob)

print("Las claves descifradas son:")
print("k1 es ", k1.hex())
print("k2 es ", k2.hex())

# Compruebo la validez de la firma con pubAlice
if funciones_rsa.comprobarRSA_PSS(k1+k2,K1K2_fir,pubAlice):#Esta comprobacion lo que hace es verifica que el mensaje 
                                #es de alice con la clave publica de Alice y obtiene la concatenacion de las claves. 
                                # Entonces por otro lado calculamos tmb la suma de las claves y vemos si coincide.
    print("Firma de K1||K2 válida")
else:
    print("Firma de K1||K2 NO válida")
    
# Recibo el mensaje, junto con el nonce del AES CTR, y el mac del HMAC
mensajeCifrado = socketserver.recibir()
nonce_16_ini = socketserver.recibir()
mac = socketserver.recibir()


# Descifro el mensaje

# Verifico el mac

# Visualizo la identidad del remitente
