from hashlib import sha256
from hmac import HMAC
import json
from socket_class import SOCKET_SIMPLE_TCP
import funciones_aes
import funciones_rsa
from Crypto.Hash import HMAC, SHA256

#Cargar la clave publica de Bob y la clave privada de Alice
pubBob = funciones_rsa.cargar_RSAKey_Publica("rsa_bob.pub")
privAlice = funciones_rsa.cargar_RSAKey_Privada("rsa_alice.pem", "alice")
        #En el archivo ca.py se generarpn las claves privadas y publicas de Alice y Bob 
        #y se guardaron en un archivo. Aqui las cargamos del archivo para poder cifrar y firmar 
        #las claves K1 y K2
        
        
#Genero las dos claves que realmente usaremos para cifrar los mensajes que se van a 
#intercambiar una vez comience la comunicacion.
k1 = funciones_aes.crear_AESKey() #Se generan en binario
k2 = funciones_aes.crear_AESKey()

print("Las claves son:")
print("k1 es ", k1.hex()) #Las muestro en hexadecimal para verlas mejor
print("k2 es ", k2.hex())

#Cifro K1 y K2 con la publica de Bob de modo que solo Bob va a poder abrirlas con su clave privada.
#Eso es la forma en que ciframos el contenido.
#Y después ciframos K1 y K2 (ya cifradas con la publica de Bob) con la privada de Alice
# (cifrar con la privada es lo mismo que decir firmar) para que Bob(y todo el mundo) sepa que es de Alice
# y no se ha modificado en el camino.
#NOOOO, LA PROFESORA NO LO HACE ASÍ. FIRMAN LA CONCATENACION DE LAS CLAVES SIN CIFRAR.
#SIMPLEMENTE ES PARA QUE CUANDO BOB RECIBA LA FIRMA Y LAS DOS CLAVES POR SEPARADO PUEDA
#COMPARARLAS DE MODO QUE SI ALGUIEN HA MODIFICADO UNA DE LAS DOS PODAMOS DETECTARLO.
#YA QUE NOSOTROS COGEMOS LA CONCATENACION DE LA FIRMA Y LA DESCONCATENAMOS Y TENEMOS LAS DOS FIRMAS 
#Y LAS COMPARAMOS CON LAS DOS CLAVES QUE HEMOS DESCIFRADO POR SEPARADO.
#YA QUE SI SOLO ENVIAMOS LAS CLAVES CIFRADAS Y NOS LAS HAN CAMBIADO Y AL DESCIFRAR TIENE SENTIDO (AUNQUE SOLO BOB PUEDA DESCCRIFRARLO CORRECTAMENTE,
# ALGUIEN PUEDE MODIFICARLO Y QUE LO QUE LE LLEGUE A BOB SE PIENSE QUE ESTÁ BIEN DESCIFRADO PORQUE TENGA SENTIDO)
# POR ESO ENVIAMOS TMB LAS CLAVES FIRMADAS POR OTRO LADO PARA HACER UNA COMPROBACION DE QUE LAS CALVES SON LAS ORIGINALES
# Y NO UNAS QUE HAN MODIFICADO Y SIGUEN TENIENDO SENTIDO

k1Cifrada = funciones_rsa.cifrarRSA_OAEP_BIN(k1, pubBob) 
k2Cifrada = funciones_rsa.cifrarRSA_OAEP_BIN(k2, pubBob)
        #Usamos cifrarRSA_OAEP_BIN porque cifrarRSA_OAEP es para cadenas y con el BIN al final es apra datos en general.
        # y k1 y k2 son array de bytes
        
        
    # Firmo la concatenación de K1 y K2 con Pri_A
K1K2_fir = funciones_rsa.firmarRSA_PSS(k1 + k2, privAlice)


#Inicializar Cliente, conectamos con el servidor y enviamos a Bob a través del socket
socketclient = SOCKET_SIMPLE_TCP('127.0.0.1', 5551)
socketclient.conectar()
print("Se inicia el cliente y se envian las claves cifradas y la firma.")

#Enviamos primero las dos claves cifradas  y despues la firma de  la concatenacion
socketclient.enviar(k1Cifrada)
socketclient.enviar(k2Cifrada)
socketclient.enviar(K1K2_fir)

#Alice le	envía	a	Bob su	nombre	(“Alice”)	y	un	nonce	(valor	aleatorio	de	128	bits)
nA = funciones_aes.crear_AESKey() #ó directamente get_random_bytes(16)

mensaje = [] #Es un array
mensaje.append("Alice") #Mete una cadena en una casilla
mensaje.append(nA.hex()) #Mete otra cadena en otra acsilla. Porque .hex() transforma un hexadecimal en una cadena.
mensajeJson = json.dumps(mensaje) #Transformo el array de cadenas en un JSON 

#Ciframos el mensaje json con k1
aes_cifrado, nonce_16_ini = funciones_aes.iniciarAES_CTR_cifrado(k1)

mensajeCifrado = funciones_aes.cifrarAES_CTR(aes_cifrado, mensajeJson.encode("utf-8")) #Transformo el Json en bytes y lo cifro

#Creo el hash y lo aplico
secret = k2
h = HMAC.new(secret, digestmod=SHA256)
h.update(mensajeCifrado)


# Envío el json cifrado junto con el nonce del AES CTR, y el mac del HMAC
socketclient.enviar(mensajeCifrado)
socketclient.enviar(nonce_16_ini)
socketclient.enviar(h.digest()) # h es el objeto MAC que tiene diversas funciones. h.digest de devuelve el mac en binario

# Recibo el mensaje, junto con el nonce del AES CTR, y el mac del HMAC
mensajeCifradoBob = socketclient.recibir()
nonce = socketclient.recibir()
mac = socketclient.recibir()

# Descifro el mensaje
aes_descifrado = funciones_aes.iniciarAES_CTR_descifrado(k1, nonce)

datos_claro = funciones_aes.descifrarAES_CTR(aes_descifrado, mensajeCifradoBob)

alice, bob, nonce_cadenaHEX  = json.loads(datos_claro.decode("utf-8", "ignore")) # Recuperamos un Array Python de un string

nonce = bytearray.fromhex(nonce_cadenaHEX) # De Hexadecimal a Bytes

# Verifico el mac


# Visualizo la identidad del remitente y compruebo si los campos enviados son los mismo que los recibidos







