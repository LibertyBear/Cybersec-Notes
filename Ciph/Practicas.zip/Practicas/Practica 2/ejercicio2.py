from Crypto.Random import get_random_bytes
from Crypto.Cipher import DES, AES
from Crypto.Util.Padding import pad,unpad
from Crypto.Util import Counter

# INICIALIZACION AES COMUN PARA TODOS LOS MODOS
#######################################

key = get_random_bytes(16)# AES -> Clave aleatoria de 128 bits
IV = get_random_bytes(16)

BLOCK_SIZE_AES = 16 #AES trabaja con bloques de 128 bits

data  = "Hola amigos de la seguridad".encode("utf-8")

dataPadded = pad(data, BLOCK_SIZE_AES)

print(data)


# ECB
###################################
print("Usando modo de operacion ECB:")
cipherECB = AES.new(key, AES.MODE_ECB)
    #ECB no necesita un vector de inicializacion porque no tiene una relacion entre bloques.
    #Unicamente utiliza una clave privada
textoCifrado = cipherECB.encrypt(dataPadded)
print(textoCifrado)


decipher = AES.new(key, AES.MODE_ECB) #No es necesario porque como es simetrico el cifrador y el descifrador son iguales.
textoDescifrado = unpad(decipher.decrypt(textoCifrado), BLOCK_SIZE_AES).decode("utf-8", "ignore")
print(textoDescifrado)


# CFB
###################################
print("Usando modo de operacion CFB:")
cipherCFB = AES.new(key, AES.MODE_CFB, IV)
textoCifrado = cipherCFB.encrypt(dataPadded)
print(textoCifrado)


decipher = AES.new(key, AES.MODE_CFB, IV) #No es necesario porque como es simetrico el cifrador y el descifrador son iguales.
textoDescifrado = unpad(decipher.decrypt(textoCifrado), BLOCK_SIZE_AES).decode("utf-8", "ignore")
print(textoDescifrado)

# OFB
###################################  ¿SÓLO DEPENDE DEL IV O TMB DEL CIFRADO ANTERIOR ?????????
print("Usando modo de operacion OFB:")
cipherOFB = AES.new(key, AES.MODE_OFB, IV)
textoCifrado = cipherOFB.encrypt(dataPadded)
print(textoCifrado)


decipher = AES.new(key, AES.MODE_OFB, IV) #No es necesario porque como es simetrico el cifrador y el descifrador son iguales.
textoDescifrado = unpad(decipher.decrypt(textoCifrado), BLOCK_SIZE_AES).decode("utf-8", "ignore")
print(textoDescifrado)


# CTR
###################################  LOS BLOQUES SON INDEPENDIENTES, PERO DOS MENSAJES IGUALES NO DAN LA MISMA ENCRIPTACIÓN COMO OCURRIA EN ECB YA QUE NUMERA LOS BLOQUES.
                   # <3 ES PARALELIZABLE E>
print("\nUsando modo de operacion CTR:")

nonce = get_random_bytes(16//2)
cipherCTR = AES.new(key, AES.MODE_CTR, nonce = nonce)
textoCifrado = cipherCTR.encrypt(dataPadded)
print(textoCifrado)


decipher = AES.new(key, AES.MODE_CTR, nonce = nonce) 
textoDescifrado = unpad(decipher.decrypt(textoCifrado), BLOCK_SIZE_AES).decode("utf-8", "ignore")
print(textoDescifrado)


# GCM
###################################  
print("\nUsando modo de operacion GCM:")

nonce = get_random_bytes(16) # == IV
mac_size = 16
cipherGCM = AES.new(key, AES.MODE_GCM, nonce=nonce, mac_len=mac_size)
textoCifrado, mac_cifrado = cipherGCM.encrypt_and_digest(dataPadded) #AQUI HAY FALLO
print(textoCifrado)

try: 
    decipher = AES.new(key, AES.MODE_GCM, nonce = nonce)
    textoDescifrado = unpad(decipher.decrypt_and_verify(textoCifrado, mac_cifrado), BLOCK_SIZE_AES).decode("utf-8", "ignore")
    print(textoDescifrado)
except (ValueError,KeyError) as e:
    print("ERROR")
    