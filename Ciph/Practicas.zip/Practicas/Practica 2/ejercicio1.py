from Crypto.Random import get_random_bytes
from Crypto.Cipher import DES, AES
from Crypto.Util.Padding import pad,unpad
from Crypto.Util import Counter

key = get_random_bytes(16) #La clave aleatoria debe ser de 128 bits a diferencia de los 64 de DES
IV = get_random_bytes(16)
#En resumen, la clave es el valor secreto que se utiliza para cifrar y descifrar los datos,
# mientras que el IV es un valor no secreto que se utiliza para inicializar el estado del cifrado y evitar ataques. 

BLOCK_SIZE_AES = 16 
#AES trabaja con bloques de 128 bits

data  = "Hola amigos de la seguridad".encode("utf-8")
#El enconde convierte el string en un array de bytes que es con lo que vamos a trabajar.
print(data)

#CIFRADO

cipher = AES.new(key, AES.MODE_CBC, IV)

textoCifrado = cipher.encrypt(pad(data, BLOCK_SIZE_AES))

print(textoCifrado)


#DESCIFRADO

decipher = AES.new(key, AES.MODE_CBC, IV)

textoDescifrado = unpad(decipher.decrypt(textoCifrado), BLOCK_SIZE_AES).decode("utf-8", "ignore")

print(textoDescifrado)
