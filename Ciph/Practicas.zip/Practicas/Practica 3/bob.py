from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Signature import pss
from Crypto.Hash import SHA256

import funcionesRSA

"""
g. Cargar la clave privada de Bob y la clave pública de Alice
"""
bobPrivKey = funcionesRSA.cargar_RSAKey_Privada("bobPriv.pem", "1234")
alicePubKey = funcionesRSA.cargar_RSAKey_Publica("alicePub.pem")

"""
h. Cargar el texto cifrado y la firma digital
"""
ficheroTextoCifrado = open("ficheroTextoCifrado.bin", "rb")
cadenaCifrada = ficheroTextoCifrado.read()
ficheroTextoCifrado.close()

ficheroFirma = open("ficheroFirma.bin", "rb")
firma = ficheroFirma.read()
ficheroFirma.close()

"""
i. Descifrar el texto cifrado y mostrarlo por pantalla.
"""
cadena = funcionesRSA.descifrarRSA_OAEP(cadenaCifrada, bobPrivKey)
print(cadena)

"""
j. Comprobar la validez de la firma digital.
"""
print("La firma es válida? ")
print(funcionesRSA.comprobarRSA_PSS(cadena,firma,alicePubKey))