from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Signature import pss
from Crypto.Hash import SHA256

#Para usar las funcioens de otro fichero se haria asi
import funcionesRSA
    #Ahora para usar la funcion es:  funcionesRSA.crear_RSAKey()

'''
a. Crear una clave pública y una clave privada RSA de 2048 bits para Alice. Guardar
cada clave en un fichero.
'''
alicePrivKey = funcionesRSA.crear_RSAKey()
alicePubKey = alicePrivKey.publickey()

funcionesRSA.guardar_RSAKey_Privada("alicePriv.pem", alicePrivKey, "1234")
funcionesRSA.guardar_RSAKey_Publica("alicePub.pem", alicePubKey)

'''
b. Crear una clave pública y una clave privada RSA de 2048 bits para Bob. Guardar
cada clave en un fichero.
'''

BobPrivKey = funcionesRSA.crear_RSAKey()
BobPubKey = BobPrivKey.publickey()

funcionesRSA.guardar_RSAKey_Privada("bobPriv.pem", BobPrivKey, "1234")
funcionesRSA.guardar_RSAKey_Publica("bobPub.pem", BobPubKey)