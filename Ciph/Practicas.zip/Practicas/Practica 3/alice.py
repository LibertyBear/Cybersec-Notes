from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Signature import pss
from Crypto.Hash import SHA256

import funcionesRSA

"""
c. Cargar la clave privada de Alice y la clave pública de Bob.
"""
alicePrivKey = funcionesRSA.cargar_RSAKey_Privada("alicePriv.pem", "1234")
BobPubKey = funcionesRSA.cargar_RSAKey_Publica("bobPub.pem")

"""
d. Cifrar el texto “Hola amigos de la seguridad” utilizando la clave de Bob.
"""
cadena = "Hola amigos de la seguridad"
cadenaCifrada = funcionesRSA.cifrarRSA_OAEP(cadena, BobPubKey)  #Es un array de bytes
print(cadena)
"""
e. Firmar el texto “Hola amigos de la seguridad” utilizando la clave de Alice.
"""
firma = funcionesRSA.firmarRSA_PSS(cadena, alicePrivKey) #Es un array de bytes

"""
f. Guardar en unos ficheros, el texto cifrado y la firma digital.
"""
ficheroTextoCifrado = open("ficheroTextoCifrado.bin", "wb") #La w es que lo vamos a abrir de escritura y la b es que lo vamos a abrir en modo binario.
ficheroTextoCifrado.write(cadenaCifrada)
ficheroTextoCifrado.close()

ficheroFirma = open("ficheroFirma.bin", "wb") #La w es que lo vamos a abrir de escritura y la b es que lo vamos a abrir en modo binario.
ficheroFirma.write(firma)
ficheroFirma.close()



